# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

<a name="1.3.0"></a>
# [1.3.0](http://164.132.200.78:8880/lecompteasso/lecompteasso/compare/v1.2.3...v1.3.0) (2018-07-26)


### Bug Fixes

* **all:** F : log.d doit également printer les log.i ([266a6c8](http://164.132.200.78:8880/lecompteasso/lecompteasso/commits/266a6c8))




<a name="1.2.0"></a>
# [1.2.0](https://git.infra.synaltic.fr/lecompteasso/lecompteasso/compare/v1.1.9...v1.2.0) (2018-05-03)




**Note:** Version bump only for package mail-server

<a name="1.1.7"></a>
## [1.1.7](https://git.infra.synaltic.fr/lecompteasso/lecompteasso/compare/v1.1.6...v1.1.7) (2018-04-06)




**Note:** Version bump only for package mail-server

<a name="1.1.3"></a>
## [1.1.3](https://git.infra.synaltic.fr/lecompteasso/lecompteasso/compare/v1.1.2...v1.1.3) (2018-03-28)




**Note:** Version bump only for package mail-server

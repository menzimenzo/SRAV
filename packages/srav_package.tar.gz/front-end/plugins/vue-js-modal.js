import Vue from 'vue'
import VModal from 'vue-js-modal/dist/ssr.index'

Vue.use(VModal, {dynamic: true, injectModalsContainer: true})
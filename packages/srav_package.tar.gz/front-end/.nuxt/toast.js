import Vue from 'vue'
import Toasted from 'vue-toasted'

Vue.use(Toasted, {"duration":15000,"iconPack":"fontawesome","action":[{"onClick":(e, toastObject) => {
                toastObject.goAway(0)
            },"icon":"check","class":"material-icons"}]})

const globals = undefined
if(globals) {
  globals.forEach(global => {
    Vue.toasted.register(global.name, global.message, global.options)
  })
}

export default function (ctx, inject) {
  inject('toast', Vue.toasted)
}

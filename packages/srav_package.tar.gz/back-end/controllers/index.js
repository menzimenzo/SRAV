module.exports = {
    oauthCallback: require('./oauthCallback'),
    pwdLogin: require('./pwdLogin'),
    generateForgotPasswordEncryption: require('./generateForgotPasswordEncryption')
}
